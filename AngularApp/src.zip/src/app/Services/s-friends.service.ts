import { Injectable, OnInit } from '@angular/core';
import { IMenuItems } from '../Models/icontact-details.model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root',
})
export class SFriendsService implements OnInit{
  url = 'http://localhost:3000/Friends';

  constructor(private http: HttpClient) {}
  ngOnInit(): void {
    
    
  }

  getAllItems(): Observable<IMenuItems[]> {
    return this.http.get<IMenuItems[]>(this.url);
  }

  public getItem(id: number): Observable<IMenuItems> {
    const tempUrl = this.url + '/' + id;
    return this.http.get<IMenuItems>(tempUrl);
  }

  
}
