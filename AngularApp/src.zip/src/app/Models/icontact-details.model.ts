export interface IMenuItems {
    id: number;
    ItemName : string;
    price : number;
    ItemDescription : string;
    imageurl : string;
}
