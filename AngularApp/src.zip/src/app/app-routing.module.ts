import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainComponent } from './Components/main/main.component';

const routes: Routes = [
  { path: '', redirectTo: 'Friends', pathMatch: 'full' },
  { path: 'Friends/contact-lists', component:  MainComponent},
  // { path: 'Friends/view/:id', component: },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
