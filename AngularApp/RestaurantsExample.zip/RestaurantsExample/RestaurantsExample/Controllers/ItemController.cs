﻿using Microsoft.AspNetCore.Mvc;
using RestaurantsExample.Models;

namespace RestaurantsExample.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class ItemController : ControllerBase
    {
        MenuComponent comp = new MenuComponent();
        [Route("GetAllItems")]
        public List<MenuItems> GetAllMenuItems()
        {
            return comp.GetAllItems();
           
        }
    }
}