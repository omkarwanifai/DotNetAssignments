﻿using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantsExample.Models
{
    [Table("RestaurantItemsTable")]
    public class MenuItems
    {
        [Key]
        public int ItemId { get; set; }
        public string ItemName { get; set; } = string.Empty;
        public int ItemPrice { get; set; }
        public string ItemImage { get; set; } = string.Empty;
        public string ItemDescription { get; set; } = string.Empty;
    }

    public class MenuItemsContext : DbContext
    {
        public DbSet<MenuItems> MenuItems { get; set; }
        
        const string connection = @"Data Source=W-674PY03-1;Initial Catalog=OmkarDb;Persist Security Info=True;User ID=sa;Password=Password@12345; TrustServerCertificate=True";
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer(connection);
        }
    }

    public interface iRestaurantComponent
    {
            public List<MenuItems> GetAllItems();
            public void AddMenuItem(MenuItems menu);
            public void RemoveMenuItem(int id);
            public void UpdateMenuItem(MenuItems menu);

    }
     class MenuComponent : iRestaurantComponent
        {
            MenuItemsContext context = new MenuItemsContext();
            public void AddMenuItem(MenuItems menu)
            {
                context.MenuItems.Add(menu);
                context.SaveChanges();
            }

            public List<MenuItems> GetAllItems()
            {
                return context.MenuItems.ToList();
            }

            public void RemoveMenuItem(int id)
            {
                var itemFound = context.MenuItems.FirstOrDefault(e => e.ItemId == id);
                if (itemFound != null)
                {
                    context.MenuItems.Remove(itemFound);
                    context.SaveChanges();
                }
                else
                {
                    throw new Exception("Item was not found...");
                }
            }

            public void UpdateMenuItem(MenuItems menu)
            {
                var itemFound = context.MenuItems.FirstOrDefault(e => e.ItemId == menu.ItemId);
                if (itemFound != null)
                {
                    itemFound.ItemName = menu.ItemName;
                    itemFound.ItemPrice = menu.ItemPrice;
                    itemFound.ItemDescription = menu.ItemDescription;
                    context.SaveChanges();
                }
                else
                {
                    throw new Exception("The item was not found...");
                }
            }
        }
    }


